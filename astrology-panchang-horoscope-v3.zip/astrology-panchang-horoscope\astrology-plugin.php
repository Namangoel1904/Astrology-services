<?php
/**
 * Plugin Name: Astrology Panchang & Horoscope
 * Plugin URI: https://yoursite.com
 * Description: A complete astrology solution with Panchang and Daily Horoscope features
 * Version: 1.0.0
 * Author: Your Name
 * License: GPL v2 or later
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

// Define plugin constants
define('ASTROLOGY_PLUGIN_URL', plugin_dir_url(__FILE__));
define('ASTROLOGY_PLUGIN_PATH', plugin_dir_path(__FILE__));

class AstrologyPlugin {
    
    public function __construct() {
        add_action('init', array($this, 'init'));
        add_action('wp_enqueue_scripts', array($this, 'enqueue_scripts'));
        add_shortcode('astrology_page', array($this, 'astrology_shortcode'));
        add_action('wp_ajax_astrology_panchang', array($this, 'handle_panchang_request'));
        add_action('wp_ajax_astrology_horoscope', array($this, 'handle_horoscope_request'));
        add_action('wp_ajax_astrology_geocode', array($this, 'handle_geocode_request'));
        add_action('wp_ajax_nopriv_astrology_panchang', array($this, 'handle_panchang_request'));
        add_action('wp_ajax_nopriv_astrology_horoscope', array($this, 'handle_horoscope_request'));
        add_action('wp_ajax_nopriv_astrology_geocode', array($this, 'handle_geocode_request'));
    }
    
    public function init() {
        // Plugin initialization
    }
    
    public function enqueue_scripts() {
        wp_enqueue_script('jquery');
        wp_enqueue_style('astrology-style', ASTROLOGY_PLUGIN_URL . 'assets/style.css', array(), '1.0.0');
        wp_enqueue_script('astrology-script', ASTROLOGY_PLUGIN_URL . 'assets/script.js', array('jquery'), '1.0.0', true);
        
        // Localize script for AJAX
        wp_localize_script('astrology-script', 'astrology_ajax', array(
            'ajax_url' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('astrology_nonce')
        ));
    }
    
    public function astrology_shortcode($atts) {
        $atts = shortcode_atts(array(
            'title' => 'पंचांग आणि दैनिक भविष्य',
            'subtitle' => 'दैनिक पंचांग तपशील आणि राशिफल'
        ), $atts);
        
        ob_start();
        ?>
        <div id="astrology-container">
            <!-- Header -->
            <div class="astrology-header">
                <div class="astrology-container">
                    <h1><?php echo esc_html($atts['title']); ?></h1>
                    <p><?php echo esc_html($atts['subtitle']); ?></p>
                </div>
            </div>

            <div class="astrology-main-content">
                <div class="astrology-container">
                    <div class="astrology-grid">
                        <!-- Panchang Section -->
                        <div class="astrology-card">
                            <div class="astrology-card-header">
                                <h2>आजचे पंचांग</h2>
                                <p>दैनिक पंचांग तपशील</p>
                            </div>
                            
                            <form id="astrology-panchang-form">
                                <div class="astrology-form-group">
                                    <label class="astrology-form-label">शहर शोधा</label>
                                    <input type="text" id="astrology-city" class="astrology-form-input" placeholder="उदा. मुंबई, पुणे, दिल्ली">
                                </div>

                                <div class="astrology-form-group">
                                    <label class="astrology-form-label">तारीख (DD/MM/YYYY)</label>
                                    <div class="astrology-form-row">
                                        <input type="text" id="astrology-date" name="date" class="astrology-form-input" placeholder="17/10/2025" required>
                                        <button type="button" id="astrology-today-btn" class="astrology-btn astrology-btn-outline">आज</button>
                                    </div>
                                </div>

                                <input type="hidden" id="astrology-lat" name="lat" value="19.0760">
                                <input type="hidden" id="astrology-lon" name="lon" value="72.8777">

                                <div class="astrology-form-group">
                                    <label class="astrology-form-label">वेळ क्षेत्र (e.g. 5.5)</label>
                                    <input type="text" id="astrology-tz" name="tz" class="astrology-form-input" value="5.5" placeholder="5.5" required>
                                </div>
                                <input type="hidden" id="astrology-lang" name="lang" value="mr">

                                <div class="astrology-form-group">
                                    <button type="submit" id="astrology-panchang-btn" class="astrology-btn astrology-btn-primary">
                                        पंचांग मिळवा
                                    </button>
                                </div>
                            </form>

                            <div id="astrology-panchang-error" class="astrology-error astrology-hidden"></div>
                            <div id="astrology-panchang-result" class="astrology-result-section astrology-hidden"></div>
                        </div>

                        <!-- Horoscope Section -->
                        <div class="astrology-card">
                            <div class="astrology-card-header">
                                <h2>दैनिक राशिफल</h2>
                                <p>आपल्या राशीचे दैनिक भविष्य</p>
                            </div>
                            
                            <form id="astrology-horoscope-form">
                                <div class="astrology-form-group">
                                    <label class="astrology-form-label">तारीख (DD/MM/YYYY)</label>
                                    <div class="astrology-form-row">
                                        <input type="text" id="astrology-horoscope-date" name="horoscope-date" class="astrology-form-input" placeholder="17/10/2025" required>
                                        <button type="button" id="astrology-horoscope-today-btn" class="astrology-btn astrology-btn-outline">आज</button>
                                    </div>
                                </div>

                                <div class="astrology-form-group">
                                    <label class="astrology-form-label">राशी निवडा</label>
                                    <select id="astrology-zodiac" name="zodiac" class="astrology-form-input" required>
                                        <option value="">आपली राशी निवडा</option>
                                        <option value="1">मेष (Aries)</option>
                                        <option value="2">वृषभ (Taurus)</option>
                                        <option value="3">मिथुन (Gemini)</option>
                                        <option value="4">कर्क (Cancer)</option>
                                        <option value="5">सिंह (Leo)</option>
                                        <option value="6">कन्या (Virgo)</option>
                                        <option value="7">तुला (Libra)</option>
                                        <option value="8">वृश्चिक (Scorpio)</option>
                                        <option value="9">धनु (Sagittarius)</option>
                                        <option value="10">मकर (Capricorn)</option>
                                        <option value="11">कुंभ (Aquarius)</option>
                                        <option value="12">मीन (Pisces)</option>
                                    </select>
                                </div>

                                <div class="astrology-form-group">
                                    <button type="submit" id="astrology-horoscope-btn" class="astrology-btn astrology-btn-secondary">
                                        राशिफल मिळवा
                                    </button>
                                </div>
                            </form>

                            <div id="astrology-horoscope-error" class="astrology-error astrology-hidden"></div>
                            <div id="astrology-horoscope-result" class="astrology-result-section astrology-hidden"></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <?php
        return ob_get_clean();
    }
    
    public function handle_panchang_request() {
        // Verify nonce
        if (!wp_verify_nonce($_POST['nonce'], 'astrology_nonce')) {
            wp_die('Security check failed');
        }
        
        $date = sanitize_text_field($_POST['date']);
        $lat = sanitize_text_field($_POST['lat']);
        $lon = sanitize_text_field($_POST['lon']);
        $tz = sanitize_text_field($_POST['tz']);
        $lang = sanitize_text_field($_POST['lang']);
        
        // Call VedicAstroAPI
        $api_key = '6bff3246-afb9-5027-92c1-f2c6f1c182f5';
        $api_url = 'https://api.vedicastroapi.com/v3-json/panchang';
        
        $params = array(
            'api_key' => $api_key,
            'date' => $date,
            'lat' => $lat,
            'lon' => $lon,
            'tz' => $tz,
            'lang' => $lang
        );
        
        $response = wp_remote_get($api_url . '?' . http_build_query($params), array(
            'timeout' => 30,
            'headers' => array(
                'User-Agent' => 'WordPress Astrology Plugin'
            )
        ));
        
        if (is_wp_error($response)) {
            wp_send_json_error('API request failed: ' . $response->get_error_message());
        }
        
        $body = wp_remote_retrieve_body($response);
        $data = json_decode($body, true);
        
        if (!$data || !isset($data['response'])) {
            wp_send_json_error('Invalid API response');
        }
        
        wp_send_json_success($data['response']);
    }
    
    public function handle_horoscope_request() {
        // Verify nonce
        if (!wp_verify_nonce($_POST['nonce'], 'astrology_nonce')) {
            wp_die('Security check failed');
        }
        
        $date = sanitize_text_field($_POST['date']);
        $zodiac = sanitize_text_field($_POST['zodiac']);
        
        // Call VedicAstroAPI
        $api_key = '6bff3246-afb9-5027-92c1-f2c6f1c182f5';
        $api_url = 'https://api.vedicastroapi.com/v3-json/prediction/daily-sun';
        
        $params = array(
            'api_key' => $api_key,
            'date' => $date,
            'zodiac' => $zodiac,
            'split' => 'false',
            'type' => 'big',
            'lang' => 'mr'
        );
        
        $response = wp_remote_get($api_url . '?' . http_build_query($params), array(
            'timeout' => 30,
            'headers' => array(
                'User-Agent' => 'WordPress Astrology Plugin'
            )
        ));
        
        if (is_wp_error($response)) {
            wp_send_json_error('API request failed: ' . $response->get_error_message());
        }
        
        $body = wp_remote_retrieve_body($response);
        $data = json_decode($body, true);
        
        if (!$data || !isset($data['response'])) {
            wp_send_json_error('Invalid API response');
        }
        
        wp_send_json_success($data['response']);
    }
    
    public function handle_geocode_request() {
        // Verify nonce
        if (!wp_verify_nonce($_POST['nonce'], 'astrology_nonce')) {
            wp_die('Security check failed');
        }
        
        $query = sanitize_text_field($_POST['q']);
        $limit = intval($_POST['limit']) ?: 8;
        $countrycodes = sanitize_text_field($_POST['countrycodes']) ?: 'in';
        
        // Call Nominatim Geocoding API
        $api_url = 'https://nominatim.openstreetmap.org/search';
        $params = array(
            'q' => $query,
            'format' => 'json',
            'limit' => $limit,
            'countrycodes' => $countrycodes
        );
        
        $response = wp_remote_get($api_url . '?' . http_build_query($params), array(
            'timeout' => 30,
            'headers' => array(
                'User-Agent' => 'WordPress Astrology Plugin'
            )
        ));
        
        if (is_wp_error($response)) {
            wp_send_json_error('Geocoding request failed: ' . $response->get_error_message());
        }
        
        $body = wp_remote_retrieve_body($response);
        $data = json_decode($body, true);
        
        if (!$data || !is_array($data)) {
            wp_send_json_error('Invalid geocoding response');
        }
        
        wp_send_json_success($data);
    }
}

// Initialize the plugin
new AstrologyPlugin();

// Create assets directory and files
register_activation_hook(__FILE__, 'astrology_plugin_activate');

function astrology_plugin_activate() {
    // Create assets directory
    $upload_dir = wp_upload_dir();
    $assets_dir = $upload_dir['basedir'] . '/astrology-plugin-assets';
    
    if (!file_exists($assets_dir)) {
        wp_mkdir_p($assets_dir);
    }
}
